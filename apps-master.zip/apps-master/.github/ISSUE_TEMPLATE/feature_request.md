---
name: Feature request
about: Suggest an idea for an app
title: ''
labels: ''
assignees: ''

---

If you want to request a new feature for an app, please go to our [marketplace](https://www.contentful.com/marketplace/) select the app you are interested in, and then submit your feature request through the support link on the right sidebar.
