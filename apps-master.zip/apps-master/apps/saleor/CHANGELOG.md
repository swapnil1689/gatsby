# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.6.55](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.54...@contentful/saleor@1.6.55) (2022-04-29)

**Note:** Version bump only for package @contentful/saleor





## [1.6.54](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.53...@contentful/saleor@1.6.54) (2022-04-29)

**Note:** Version bump only for package @contentful/saleor





## [1.6.53](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.52...@contentful/saleor@1.6.53) (2022-04-29)

**Note:** Version bump only for package @contentful/saleor





## [1.6.52](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.51...@contentful/saleor@1.6.52) (2022-04-27)

**Note:** Version bump only for package @contentful/saleor





## [1.6.51](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.50...@contentful/saleor@1.6.51) (2022-04-27)

**Note:** Version bump only for package @contentful/saleor





## [1.6.50](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.49...@contentful/saleor@1.6.50) (2022-04-27)

**Note:** Version bump only for package @contentful/saleor





## [1.6.49](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.48...@contentful/saleor@1.6.49) (2022-04-25)

**Note:** Version bump only for package @contentful/saleor





## [1.6.48](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.47...@contentful/saleor@1.6.48) (2022-04-25)

**Note:** Version bump only for package @contentful/saleor





## [1.6.47](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.46...@contentful/saleor@1.6.47) (2022-04-22)

**Note:** Version bump only for package @contentful/saleor





## [1.6.46](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.45...@contentful/saleor@1.6.46) (2022-04-19)

**Note:** Version bump only for package @contentful/saleor





## [1.6.45](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.44...@contentful/saleor@1.6.45) (2022-04-19)

**Note:** Version bump only for package @contentful/saleor





## [1.6.44](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.43...@contentful/saleor@1.6.44) (2022-04-15)

**Note:** Version bump only for package @contentful/saleor





## [1.6.43](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.42...@contentful/saleor@1.6.43) (2022-04-15)

**Note:** Version bump only for package @contentful/saleor





## [1.6.42](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.41...@contentful/saleor@1.6.42) (2022-04-15)

**Note:** Version bump only for package @contentful/saleor





## [1.6.41](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.40...@contentful/saleor@1.6.41) (2022-04-11)

**Note:** Version bump only for package @contentful/saleor





## [1.6.40](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.39...@contentful/saleor@1.6.40) (2022-04-11)

**Note:** Version bump only for package @contentful/saleor





## [1.6.39](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.38...@contentful/saleor@1.6.39) (2022-04-08)

**Note:** Version bump only for package @contentful/saleor





## [1.6.38](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.37...@contentful/saleor@1.6.38) (2022-04-05)

**Note:** Version bump only for package @contentful/saleor





## [1.6.37](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.36...@contentful/saleor@1.6.37) (2022-04-05)

**Note:** Version bump only for package @contentful/saleor





## [1.6.36](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.35...@contentful/saleor@1.6.36) (2022-03-28)

**Note:** Version bump only for package @contentful/saleor





## [1.6.35](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.34...@contentful/saleor@1.6.35) (2022-03-25)

**Note:** Version bump only for package @contentful/saleor





## [1.6.34](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.33...@contentful/saleor@1.6.34) (2022-03-25)

**Note:** Version bump only for package @contentful/saleor





## [1.6.33](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.32...@contentful/saleor@1.6.33) (2022-03-24)

**Note:** Version bump only for package @contentful/saleor





## [1.6.32](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.31...@contentful/saleor@1.6.32) (2022-03-24)

**Note:** Version bump only for package @contentful/saleor





## [1.6.31](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.30...@contentful/saleor@1.6.31) (2022-03-22)

**Note:** Version bump only for package @contentful/saleor





## [1.6.30](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.29...@contentful/saleor@1.6.30) (2022-03-21)

**Note:** Version bump only for package @contentful/saleor





## [1.6.29](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.28...@contentful/saleor@1.6.29) (2022-03-21)

**Note:** Version bump only for package @contentful/saleor





## [1.6.28](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.27...@contentful/saleor@1.6.28) (2022-03-11)

**Note:** Version bump only for package @contentful/saleor





## [1.6.27](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.26...@contentful/saleor@1.6.27) (2022-03-03)

**Note:** Version bump only for package @contentful/saleor





## [1.6.26](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.25...@contentful/saleor@1.6.26) (2022-03-02)

**Note:** Version bump only for package @contentful/saleor





## [1.6.25](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.24...@contentful/saleor@1.6.25) (2022-02-28)

**Note:** Version bump only for package @contentful/saleor





## [1.6.24](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.23...@contentful/saleor@1.6.24) (2022-02-24)


### Bug Fixes

* **deps:** bump contentful-management from 7.30.0 to 8.1.3 ([#873](https://github.com/contentful/apps/issues/873)) ([50ec8fe](https://github.com/contentful/apps/commit/50ec8fec9be6fcbd45fbe0f918aaaf2935361dc2))





## [1.6.23](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.22...@contentful/saleor@1.6.23) (2022-02-24)

**Note:** Version bump only for package @contentful/saleor





## [1.6.22](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.21...@contentful/saleor@1.6.22) (2022-02-24)

**Note:** Version bump only for package @contentful/saleor





## [1.6.21](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.20...@contentful/saleor@1.6.21) (2022-02-22)

**Note:** Version bump only for package @contentful/saleor





## [1.6.20](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.19...@contentful/saleor@1.6.20) (2022-02-21)

**Note:** Version bump only for package @contentful/saleor





## [1.6.19](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.18...@contentful/saleor@1.6.19) (2022-02-17)

**Note:** Version bump only for package @contentful/saleor





## [1.6.18](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.17...@contentful/saleor@1.6.18) (2022-02-15)

**Note:** Version bump only for package @contentful/saleor





## [1.6.17](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.16...@contentful/saleor@1.6.17) (2022-02-15)

**Note:** Version bump only for package @contentful/saleor





## [1.6.16](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.15...@contentful/saleor@1.6.16) (2022-02-08)

**Note:** Version bump only for package @contentful/saleor





## [1.6.15](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.14...@contentful/saleor@1.6.15) (2022-02-08)

**Note:** Version bump only for package @contentful/saleor





## [1.6.14](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.13...@contentful/saleor@1.6.14) (2022-02-07)

**Note:** Version bump only for package @contentful/saleor





## [1.6.13](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.12...@contentful/saleor@1.6.13) (2022-02-07)

**Note:** Version bump only for package @contentful/saleor





## [1.6.12](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.11...@contentful/saleor@1.6.12) (2022-02-04)

**Note:** Version bump only for package @contentful/saleor





## [1.6.11](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.10...@contentful/saleor@1.6.11) (2022-02-02)

**Note:** Version bump only for package @contentful/saleor





## [1.6.10](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.9...@contentful/saleor@1.6.10) (2022-01-28)

**Note:** Version bump only for package @contentful/saleor





## [1.6.9](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.8...@contentful/saleor@1.6.9) (2022-01-26)

**Note:** Version bump only for package @contentful/saleor





## [1.6.8](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.7...@contentful/saleor@1.6.8) (2022-01-22)

**Note:** Version bump only for package @contentful/saleor





## [1.6.7](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.6...@contentful/saleor@1.6.7) (2022-01-21)

**Note:** Version bump only for package @contentful/saleor





## [1.6.6](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.5...@contentful/saleor@1.6.6) (2022-01-21)

**Note:** Version bump only for package @contentful/saleor





## [1.6.5](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.4...@contentful/saleor@1.6.5) (2022-01-19)

**Note:** Version bump only for package @contentful/saleor





## [1.6.4](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.3...@contentful/saleor@1.6.4) (2022-01-18)

**Note:** Version bump only for package @contentful/saleor





## [1.6.3](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.2...@contentful/saleor@1.6.3) (2022-01-18)

**Note:** Version bump only for package @contentful/saleor





## [1.6.2](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.1...@contentful/saleor@1.6.2) (2022-01-17)

**Note:** Version bump only for package @contentful/saleor





## [1.6.1](https://github.com/contentful/apps/compare/@contentful/saleor@1.6.0...@contentful/saleor@1.6.1) (2022-01-16)

**Note:** Version bump only for package @contentful/saleor





# 1.6.0 (2022-01-14)


### Bug Fixes

* move react to peer dependency & unpin dependencies ([#475](https://github.com/contentful/apps/issues/475)) ([981e177](https://github.com/contentful/apps/commit/981e177092fafdcce211822277d3ee0dad7ae689))
* pin version for ecommerce base app ([#193](https://github.com/contentful/apps/issues/193)) ([0984a04](https://github.com/contentful/apps/commit/0984a044244df77d90190a8f110af7825a676628))
* remove unused dependencies ([#523](https://github.com/contentful/apps/issues/523)) ([a1af1dd](https://github.com/contentful/apps/commit/a1af1dd07726c1119e0c16fcbdfb3bea4f88dae2))


### Features

* [EXT-2533] use new version of ecommerce base app ([#239](https://github.com/contentful/apps/issues/239)) ([b4f398f](https://github.com/contentful/apps/commit/b4f398f7fe4fb2952e8505a7657b876861fe3a24))
* [EXT-2717] deploy saleor with app hosting ([#366](https://github.com/contentful/apps/issues/366)) ([ae7606a](https://github.com/contentful/apps/commit/ae7606afd346001dc8b11effa699bffcfb1b9090))
* [EXT-2722] use contentful hosting for image focal point app ([#238](https://github.com/contentful/apps/issues/238)) ([11b57ae](https://github.com/contentful/apps/commit/11b57ae3e4fb5dd376544d89056430b71883517c))
* [EXT-3415] move all package names to [@contentful](https://github.com/contentful) ([#665](https://github.com/contentful/apps/issues/665)) ([9bd7534](https://github.com/contentful/apps/commit/9bd75340860e59f25b4eed900a832a482508f603))
* update commercelayer and saleor to use cca ([#268](https://github.com/contentful/apps/issues/268)) ([fbd8ef6](https://github.com/contentful/apps/commit/fbd8ef61eba59625e2bc55403be94c250b2df8bf))
* use App SDK v4 ([#528](https://github.com/contentful/apps/issues/528)) ([5fb634a](https://github.com/contentful/apps/commit/5fb634a0679de8af4ada0de3d571a8a5e5564090))


### Reverts

* Revert "feat: [EXT-2533] use new version of ecommerce base app (#239)" (#251) ([dae2ae6](https://github.com/contentful/apps/commit/dae2ae66181543a93981b1b97cc9dfc71e5abf16)), closes [#239](https://github.com/contentful/apps/issues/239) [#251](https://github.com/contentful/apps/issues/251)



## 1.0.1 (2021-01-11)



# 1.0.0 (2021-01-08)


### Bug Fixes

* fix CI builds for saleor app ([a6d097c](https://github.com/contentful/apps/commit/a6d097c4d3c126d98e36c28772ad23ad0c7e8657))





## [1.5.54](https://github.com/contentful/apps/compare/saleor@1.5.53...saleor@1.5.54) (2022-01-10)

**Note:** Version bump only for package saleor





## [1.5.53](https://github.com/contentful/apps/compare/saleor@1.5.52...saleor@1.5.53) (2022-01-06)

**Note:** Version bump only for package saleor





## [1.5.52](https://github.com/contentful/apps/compare/saleor@1.5.51...saleor@1.5.52) (2022-01-05)

**Note:** Version bump only for package saleor





## [1.5.51](https://github.com/contentful/apps/compare/saleor@1.5.50...saleor@1.5.51) (2022-01-05)

**Note:** Version bump only for package saleor





## [1.5.50](https://github.com/contentful/apps/compare/saleor@1.5.49...saleor@1.5.50) (2022-01-04)

**Note:** Version bump only for package saleor





## [1.5.49](https://github.com/contentful/apps/compare/saleor@1.5.48...saleor@1.5.49) (2022-01-03)

**Note:** Version bump only for package saleor





## [1.5.48](https://github.com/contentful/apps/compare/saleor@1.5.47...saleor@1.5.48) (2021-12-31)

**Note:** Version bump only for package saleor





## [1.5.47](https://github.com/contentful/apps/compare/saleor@1.5.46...saleor@1.5.47) (2021-12-27)

**Note:** Version bump only for package saleor





## [1.5.46](https://github.com/contentful/apps/compare/saleor@1.5.45...saleor@1.5.46) (2021-12-24)

**Note:** Version bump only for package saleor





## [1.5.45](https://github.com/contentful/apps/compare/saleor@1.5.44...saleor@1.5.45) (2021-12-24)

**Note:** Version bump only for package saleor





## [1.5.44](https://github.com/contentful/apps/compare/saleor@1.5.43...saleor@1.5.44) (2021-12-21)

**Note:** Version bump only for package saleor





## [1.5.43](https://github.com/contentful/apps/compare/saleor@1.5.42...saleor@1.5.43) (2021-12-20)

**Note:** Version bump only for package saleor





## [1.5.42](https://github.com/contentful/apps/compare/saleor@1.5.41...saleor@1.5.42) (2021-12-17)

**Note:** Version bump only for package saleor





## [1.5.41](https://github.com/contentful/apps/compare/saleor@1.5.40...saleor@1.5.41) (2021-12-16)

**Note:** Version bump only for package saleor





## [1.5.40](https://github.com/contentful/apps/compare/saleor@1.5.39...saleor@1.5.40) (2021-12-15)

**Note:** Version bump only for package saleor





## [1.5.39](https://github.com/contentful/apps/compare/saleor@1.5.38...saleor@1.5.39) (2021-12-14)

**Note:** Version bump only for package saleor





## [1.5.38](https://github.com/contentful/apps/compare/saleor@1.5.37...saleor@1.5.38) (2021-12-13)

**Note:** Version bump only for package saleor





## [1.5.37](https://github.com/contentful/apps/compare/saleor@1.5.36...saleor@1.5.37) (2021-12-10)

**Note:** Version bump only for package saleor





## [1.5.36](https://github.com/contentful/apps/compare/saleor@1.5.35...saleor@1.5.36) (2021-12-09)

**Note:** Version bump only for package saleor





## [1.5.35](https://github.com/contentful/apps/compare/saleor@1.5.34...saleor@1.5.35) (2021-12-08)

**Note:** Version bump only for package saleor





## [1.5.34](https://github.com/contentful/apps/compare/saleor@1.5.33...saleor@1.5.34) (2021-12-06)

**Note:** Version bump only for package saleor





## [1.5.33](https://github.com/contentful/apps/compare/saleor@1.5.32...saleor@1.5.33) (2021-12-02)

**Note:** Version bump only for package saleor





## [1.5.32](https://github.com/contentful/apps/compare/saleor@1.5.31...saleor@1.5.32) (2021-12-01)

**Note:** Version bump only for package saleor





## [1.5.31](https://github.com/contentful/apps/compare/saleor@1.5.30...saleor@1.5.31) (2021-12-01)

**Note:** Version bump only for package saleor





## [1.5.30](https://github.com/contentful/apps/compare/saleor@1.5.29...saleor@1.5.30) (2021-11-30)

**Note:** Version bump only for package saleor





## [1.5.29](https://github.com/contentful/apps/compare/saleor@1.5.28...saleor@1.5.29) (2021-11-26)

**Note:** Version bump only for package saleor





## [1.5.28](https://github.com/contentful/apps/compare/saleor@1.5.27...saleor@1.5.28) (2021-11-25)

**Note:** Version bump only for package saleor





## [1.5.27](https://github.com/contentful/apps/compare/saleor@1.5.26...saleor@1.5.27) (2021-11-24)

**Note:** Version bump only for package saleor





## [1.5.26](https://github.com/contentful/apps/compare/saleor@1.5.25...saleor@1.5.26) (2021-11-22)

**Note:** Version bump only for package saleor





## [1.5.25](https://github.com/contentful/apps/compare/saleor@1.5.24...saleor@1.5.25) (2021-11-22)

**Note:** Version bump only for package saleor





## [1.5.24](https://github.com/contentful/apps/compare/saleor@1.5.23...saleor@1.5.24) (2021-11-19)

**Note:** Version bump only for package saleor





## [1.5.23](https://github.com/contentful/apps/compare/saleor@1.5.22...saleor@1.5.23) (2021-11-19)

**Note:** Version bump only for package saleor





## [1.5.22](https://github.com/contentful/apps/compare/saleor@1.5.21...saleor@1.5.22) (2021-11-16)

**Note:** Version bump only for package saleor





## [1.5.21](https://github.com/contentful/apps/compare/saleor@1.5.20...saleor@1.5.21) (2021-11-15)

**Note:** Version bump only for package saleor





## [1.5.20](https://github.com/contentful/apps/compare/saleor@1.5.19...saleor@1.5.20) (2021-11-15)

**Note:** Version bump only for package saleor





## [1.5.19](https://github.com/contentful/apps/compare/saleor@1.5.18...saleor@1.5.19) (2021-11-09)

**Note:** Version bump only for package saleor





## [1.5.18](https://github.com/contentful/apps/compare/saleor@1.5.17...saleor@1.5.18) (2021-11-08)

**Note:** Version bump only for package saleor





## [1.5.17](https://github.com/contentful/apps/compare/saleor@1.5.16...saleor@1.5.17) (2021-11-04)

**Note:** Version bump only for package saleor





## [1.5.16](https://github.com/contentful/apps/compare/saleor@1.5.15...saleor@1.5.16) (2021-11-04)

**Note:** Version bump only for package saleor





## [1.5.15](https://github.com/contentful/apps/compare/saleor@1.5.14...saleor@1.5.15) (2021-10-28)

**Note:** Version bump only for package saleor





## [1.5.14](https://github.com/contentful/apps/compare/saleor@1.5.13...saleor@1.5.14) (2021-10-26)

**Note:** Version bump only for package saleor





## [1.5.13](https://github.com/contentful/apps/compare/saleor@1.5.12...saleor@1.5.13) (2021-10-26)

**Note:** Version bump only for package saleor





## [1.5.12](https://github.com/contentful/apps/compare/saleor@1.5.11...saleor@1.5.12) (2021-10-25)

**Note:** Version bump only for package saleor





## [1.5.11](https://github.com/contentful/apps/compare/saleor@1.5.10...saleor@1.5.11) (2021-10-25)

**Note:** Version bump only for package saleor





## [1.5.10](https://github.com/contentful/apps/compare/saleor@1.5.9...saleor@1.5.10) (2021-10-22)

**Note:** Version bump only for package saleor





## [1.5.9](https://github.com/contentful/apps/compare/saleor@1.5.8...saleor@1.5.9) (2021-10-22)

**Note:** Version bump only for package saleor





## [1.5.8](https://github.com/contentful/apps/compare/saleor@1.5.7...saleor@1.5.8) (2021-10-21)

**Note:** Version bump only for package saleor





## [1.5.7](https://github.com/contentful/apps/compare/saleor@1.5.6...saleor@1.5.7) (2021-10-20)

**Note:** Version bump only for package saleor





## [1.5.6](https://github.com/contentful/apps/compare/saleor@1.5.5...saleor@1.5.6) (2021-10-18)

**Note:** Version bump only for package saleor





## [1.5.5](https://github.com/contentful/apps/compare/saleor@1.5.4...saleor@1.5.5) (2021-10-18)

**Note:** Version bump only for package saleor





## [1.5.4](https://github.com/contentful/apps/compare/saleor@1.5.3...saleor@1.5.4) (2021-10-15)

**Note:** Version bump only for package saleor





## [1.5.3](https://github.com/contentful/apps/compare/saleor@1.5.2...saleor@1.5.3) (2021-10-15)

**Note:** Version bump only for package saleor





## [1.5.2](https://github.com/contentful/apps/compare/saleor@1.5.1...saleor@1.5.2) (2021-10-14)

**Note:** Version bump only for package saleor





## [1.5.1](https://github.com/contentful/apps/compare/saleor@1.5.0...saleor@1.5.1) (2021-10-14)

**Note:** Version bump only for package saleor





# [1.5.0](https://github.com/contentful/apps/compare/saleor@1.4.46...saleor@1.5.0) (2021-10-13)


### Features

* use App SDK v4 ([#528](https://github.com/contentful/apps/issues/528)) ([5fb634a](https://github.com/contentful/apps/commit/5fb634a0679de8af4ada0de3d571a8a5e5564090))





## [1.4.46](https://github.com/contentful/apps/compare/saleor@1.4.45...saleor@1.4.46) (2021-10-13)

**Note:** Version bump only for package saleor





## [1.4.45](https://github.com/contentful/apps/compare/saleor@1.4.44...saleor@1.4.45) (2021-10-13)

**Note:** Version bump only for package saleor





## [1.4.44](https://github.com/contentful/apps/compare/saleor@1.4.43...saleor@1.4.44) (2021-10-11)

**Note:** Version bump only for package saleor





## [1.4.43](https://github.com/contentful/apps/compare/saleor@1.4.42...saleor@1.4.43) (2021-10-07)


### Bug Fixes

* remove unused dependencies ([#523](https://github.com/contentful/apps/issues/523)) ([a1af1dd](https://github.com/contentful/apps/commit/a1af1dd07726c1119e0c16fcbdfb3bea4f88dae2))





## [1.4.42](https://github.com/contentful/apps/compare/saleor@1.4.41...saleor@1.4.42) (2021-10-07)

**Note:** Version bump only for package saleor





## [1.4.41](https://github.com/contentful/apps/compare/saleor@1.4.40...saleor@1.4.41) (2021-10-06)

**Note:** Version bump only for package saleor





## [1.4.40](https://github.com/contentful/apps/compare/saleor@1.4.39...saleor@1.4.40) (2021-10-04)

**Note:** Version bump only for package saleor





## [1.4.39](https://github.com/contentful/apps/compare/saleor@1.4.38...saleor@1.4.39) (2021-09-30)

**Note:** Version bump only for package saleor





## [1.4.38](https://github.com/contentful/apps/compare/saleor@1.4.37...saleor@1.4.38) (2021-09-30)

**Note:** Version bump only for package saleor





## [1.4.37](https://github.com/contentful/apps/compare/saleor@1.4.36...saleor@1.4.37) (2021-09-29)

**Note:** Version bump only for package saleor





## [1.4.36](https://github.com/contentful/apps/compare/saleor@1.4.35...saleor@1.4.36) (2021-09-27)

**Note:** Version bump only for package saleor





## [1.4.35](https://github.com/contentful/apps/compare/saleor@1.4.34...saleor@1.4.35) (2021-09-24)

**Note:** Version bump only for package saleor





## [1.4.34](https://github.com/contentful/apps/compare/saleor@1.4.33...saleor@1.4.34) (2021-09-22)

**Note:** Version bump only for package saleor





## [1.4.33](https://github.com/contentful/apps/compare/saleor@1.4.32...saleor@1.4.33) (2021-09-22)

**Note:** Version bump only for package saleor





## [1.4.32](https://github.com/contentful/apps/compare/saleor@1.4.31...saleor@1.4.32) (2021-09-22)

**Note:** Version bump only for package saleor





## [1.4.31](https://github.com/contentful/apps/compare/saleor@1.4.30...saleor@1.4.31) (2021-09-21)

**Note:** Version bump only for package saleor





## [1.4.30](https://github.com/contentful/apps/compare/saleor@1.4.29...saleor@1.4.30) (2021-09-21)

**Note:** Version bump only for package saleor





## [1.4.29](https://github.com/contentful/apps/compare/saleor@1.4.28...saleor@1.4.29) (2021-09-20)

**Note:** Version bump only for package saleor





## [1.4.28](https://github.com/contentful/apps/compare/saleor@1.4.27...saleor@1.4.28) (2021-09-20)

**Note:** Version bump only for package saleor





## [1.4.27](https://github.com/contentful/apps/compare/saleor@1.4.26...saleor@1.4.27) (2021-09-17)

**Note:** Version bump only for package saleor





## [1.4.26](https://github.com/contentful/apps/compare/saleor@1.4.25...saleor@1.4.26) (2021-09-17)

**Note:** Version bump only for package saleor





## [1.4.25](https://github.com/contentful/apps/compare/saleor@1.4.24...saleor@1.4.25) (2021-09-17)

**Note:** Version bump only for package saleor





## [1.4.24](https://github.com/contentful/apps/compare/saleor@1.4.23...saleor@1.4.24) (2021-09-17)

**Note:** Version bump only for package saleor





## [1.4.23](https://github.com/contentful/apps/compare/saleor@1.4.22...saleor@1.4.23) (2021-09-16)

**Note:** Version bump only for package saleor





## [1.4.22](https://github.com/contentful/apps/compare/saleor@1.4.21...saleor@1.4.22) (2021-09-16)


### Bug Fixes

* move react to peer dependency & unpin dependencies ([#475](https://github.com/contentful/apps/issues/475)) ([981e177](https://github.com/contentful/apps/commit/981e177092fafdcce211822277d3ee0dad7ae689))





## [1.4.21](https://github.com/contentful/apps/compare/saleor@1.4.20...saleor@1.4.21) (2021-09-13)

**Note:** Version bump only for package saleor





## [1.4.20](https://github.com/contentful/apps/compare/saleor@1.4.19...saleor@1.4.20) (2021-09-10)

**Note:** Version bump only for package saleor





## [1.4.19](https://github.com/contentful/apps/compare/saleor@1.4.18...saleor@1.4.19) (2021-09-10)

**Note:** Version bump only for package saleor





## [1.4.18](https://github.com/contentful/apps/compare/saleor@1.4.17...saleor@1.4.18) (2021-09-06)

**Note:** Version bump only for package saleor





## [1.4.17](https://github.com/contentful/apps/compare/saleor@1.4.16...saleor@1.4.17) (2021-09-03)

**Note:** Version bump only for package saleor





## [1.4.16](https://github.com/contentful/apps/compare/saleor@1.4.15...saleor@1.4.16) (2021-09-03)

**Note:** Version bump only for package saleor





## [1.4.15](https://github.com/contentful/apps/compare/saleor@1.4.14...saleor@1.4.15) (2021-09-03)

**Note:** Version bump only for package saleor





## [1.4.14](https://github.com/contentful/apps/compare/saleor@1.4.13...saleor@1.4.14) (2021-09-02)

**Note:** Version bump only for package saleor





## [1.4.13](https://github.com/contentful/apps/compare/saleor@1.4.12...saleor@1.4.13) (2021-09-02)

**Note:** Version bump only for package saleor





## [1.4.12](https://github.com/contentful/apps/compare/saleor@1.4.11...saleor@1.4.12) (2021-08-30)

**Note:** Version bump only for package saleor





## [1.4.11](https://github.com/contentful/apps/compare/saleor@1.4.10...saleor@1.4.11) (2021-08-25)

**Note:** Version bump only for package saleor





## [1.4.10](https://github.com/contentful/apps/compare/saleor@1.4.9...saleor@1.4.10) (2021-08-20)

**Note:** Version bump only for package saleor





## [1.4.9](https://github.com/contentful/apps/compare/saleor@1.4.8...saleor@1.4.9) (2021-08-18)

**Note:** Version bump only for package saleor





## [1.4.8](https://github.com/contentful/apps/compare/saleor@1.4.7...saleor@1.4.8) (2021-08-16)

**Note:** Version bump only for package saleor





## [1.4.7](https://github.com/contentful/apps/compare/saleor@1.4.6...saleor@1.4.7) (2021-08-13)

**Note:** Version bump only for package saleor





## [1.4.6](https://github.com/contentful/apps/compare/saleor@1.4.5...saleor@1.4.6) (2021-08-11)

**Note:** Version bump only for package saleor





## [1.4.5](https://github.com/contentful/apps/compare/saleor@1.4.4...saleor@1.4.5) (2021-08-10)

**Note:** Version bump only for package saleor





## [1.4.4](https://github.com/contentful/apps/compare/saleor@1.4.3...saleor@1.4.4) (2021-08-09)

**Note:** Version bump only for package saleor





## [1.4.3](https://github.com/contentful/apps/compare/saleor@1.4.2...saleor@1.4.3) (2021-08-06)

**Note:** Version bump only for package saleor





## [1.4.2](https://github.com/contentful/apps/compare/saleor@1.4.1...saleor@1.4.2) (2021-08-05)

**Note:** Version bump only for package saleor





## [1.4.1](https://github.com/contentful/apps/compare/saleor@1.4.0...saleor@1.4.1) (2021-08-05)

**Note:** Version bump only for package saleor





# [1.4.0](https://github.com/contentful/apps/compare/saleor@1.3.12...saleor@1.4.0) (2021-08-04)


### Features

* [EXT-2717] deploy saleor with app hosting ([#366](https://github.com/contentful/apps/issues/366)) ([ae7606a](https://github.com/contentful/apps/commit/ae7606afd346001dc8b11effa699bffcfb1b9090))





## [1.3.12](https://github.com/contentful/apps/compare/saleor@1.3.11...saleor@1.3.12) (2021-08-02)

**Note:** Version bump only for package saleor





## [1.3.11](https://github.com/contentful/apps/compare/saleor@1.3.10...saleor@1.3.11) (2021-08-02)

**Note:** Version bump only for package saleor





## [1.3.10](https://github.com/contentful/apps/compare/saleor@1.3.9...saleor@1.3.10) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.9](https://github.com/contentful/apps/compare/saleor@1.3.8...saleor@1.3.9) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.8](https://github.com/contentful/apps/compare/saleor@1.3.7...saleor@1.3.8) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.7](https://github.com/contentful/apps/compare/saleor@1.3.6...saleor@1.3.7) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.6](https://github.com/contentful/apps/compare/saleor@1.3.5...saleor@1.3.6) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.5](https://github.com/contentful/apps/compare/saleor@1.3.4...saleor@1.3.5) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.4](https://github.com/contentful/apps/compare/saleor@1.3.3...saleor@1.3.4) (2021-07-28)

**Note:** Version bump only for package saleor





## [1.3.3](https://github.com/contentful/apps/compare/saleor@1.3.2...saleor@1.3.3) (2021-07-26)

**Note:** Version bump only for package saleor





## [1.3.2](https://github.com/contentful/apps/compare/saleor@1.3.1...saleor@1.3.2) (2021-06-22)

**Note:** Version bump only for package saleor





## [1.3.1](https://github.com/contentful/apps/compare/saleor@1.3.0...saleor@1.3.1) (2021-06-15)

**Note:** Version bump only for package saleor





# [1.3.0](https://github.com/contentful/apps/compare/saleor@1.2.1...saleor@1.3.0) (2021-05-27)


### Features

* update commercelayer and saleor to use cca ([#268](https://github.com/contentful/apps/issues/268)) ([fbd8ef6](https://github.com/contentful/apps/commit/fbd8ef61eba59625e2bc55403be94c250b2df8bf))





## [1.2.1](https://github.com/contentful/apps/compare/saleor@1.2.0...saleor@1.2.1) (2021-05-10)


### Reverts

* Revert "feat: [EXT-2533] use new version of ecommerce base app (#239)" (#251) ([dae2ae6](https://github.com/contentful/apps/commit/dae2ae66181543a93981b1b97cc9dfc71e5abf16)), closes [#239](https://github.com/contentful/apps/issues/239) [#251](https://github.com/contentful/apps/issues/251)





# [1.2.0](https://github.com/contentful/apps/compare/saleor@1.1.0...saleor@1.2.0) (2021-05-10)


### Features

* [EXT-2533] use new version of ecommerce base app ([#239](https://github.com/contentful/apps/issues/239)) ([b4f398f](https://github.com/contentful/apps/commit/b4f398f7fe4fb2952e8505a7657b876861fe3a24))





# [1.1.0](https://github.com/contentful/apps/compare/saleor@1.0.7...saleor@1.1.0) (2021-05-05)


### Features

* [EXT-2722] use contentful hosting for image focal point app ([#238](https://github.com/contentful/apps/issues/238)) ([11b57ae](https://github.com/contentful/apps/commit/11b57ae3e4fb5dd376544d89056430b71883517c))





## [1.0.7](https://github.com/contentful/apps/compare/saleor@1.0.6...saleor@1.0.7) (2021-02-16)


### Bug Fixes

* pin version for ecommerce base app ([#193](https://github.com/contentful/apps/issues/193)) ([0984a04](https://github.com/contentful/apps/commit/0984a044244df77d90190a8f110af7825a676628))





## [1.0.6](https://github.com/contentful/apps/compare/saleor@1.0.5...saleor@1.0.6) (2021-02-16)

**Note:** Version bump only for package saleor





## [1.0.5](https://github.com/contentful/apps/compare/saleor@1.0.4...saleor@1.0.5) (2021-02-02)

**Note:** Version bump only for package saleor





## [1.0.4](https://github.com/contentful/apps/compare/saleor@1.0.3...saleor@1.0.4) (2021-01-14)

**Note:** Version bump only for package saleor





## [1.0.3](https://github.com/contentful/apps/compare/saleor@1.0.2...saleor@1.0.3) (2021-01-14)

**Note:** Version bump only for package saleor





## 1.0.2 (2021-01-12)



## 1.0.1 (2021-01-11)



# 1.0.0 (2021-01-08)


### Bug Fixes

* fix CI builds for saleor app ([a6d097c](https://github.com/contentful/apps/commit/a6d097c4d3c126d98e36c28772ad23ad0c7e8657))
