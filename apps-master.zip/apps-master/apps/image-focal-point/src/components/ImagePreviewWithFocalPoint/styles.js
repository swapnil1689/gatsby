import { css } from 'emotion';
import tokens from '@contentful/forma-36-tokens';

export const styles = {
  device: css({
    marginTop: tokens.spacingXs,
  }),
};
