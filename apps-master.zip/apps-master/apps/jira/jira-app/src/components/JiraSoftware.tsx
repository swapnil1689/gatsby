import React from 'react';
// @ts-ignore: 2307
import logo from './logo.svg';

const JiraSoftware = () => (
  <header>
    <img src={logo} alt="Jira Software" />
  </header>
);

export default JiraSoftware;
