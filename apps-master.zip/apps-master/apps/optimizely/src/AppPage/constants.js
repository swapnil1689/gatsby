export const VARIATION_CONTAINER_ID = 'variationContainer';
