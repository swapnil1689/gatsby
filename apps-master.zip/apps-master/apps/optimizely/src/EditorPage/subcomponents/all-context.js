import React from 'react';

export const SDKContext = React.createContext(null);
export const GlobalStateContext = React.createContext(null);
