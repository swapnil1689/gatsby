export const Status = {
  SelectExperiment: 'SelectExperiment',
  AddContent: 'AddContent',
  PublishVariations: 'PublishVariations',
  StartExperiment: 'StartExperiment',
  Finished: 'Finished',
};
