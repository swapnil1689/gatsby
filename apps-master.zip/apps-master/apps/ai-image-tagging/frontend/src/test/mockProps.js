export default {
  sdk: {
    location: {},
    contentType: {},
    space: {},
    ids: {
      extension: 'ai-image-tagging',
      space: 'cyu19ucaypb9',
      environment: 'master',
      user: '2userId252',
    },
    window: {},
  },
};
