import React from 'react';
import { styles } from './styles';

export function Divider() {
  return <hr className={styles.splitter} />;
}
