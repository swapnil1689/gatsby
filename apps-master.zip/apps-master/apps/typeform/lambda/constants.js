'use strict';

const BASE_URL = 'https://api.typeform.com';

module.exports = {
  BASE_URL,
};
