declare module '@typeform/embed';
