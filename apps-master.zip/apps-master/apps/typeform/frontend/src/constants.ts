
const SDK_WINDOW_HEIGHT = 450;
const BASE_URL = 'https://api.typeform.com';
const CLIENT_ID = 'HC3UDnoiaP1UCMqJ7kCAyTFdHrDt8nLtXx4BKRJxom2M'

export {
  SDK_WINDOW_HEIGHT,
  BASE_URL,
  CLIENT_ID,
}

