# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.8.56](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.55...@contentful/shopify-sku@1.8.56) (2022-04-29)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.55](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.54...@contentful/shopify-sku@1.8.55) (2022-04-29)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.54](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.53...@contentful/shopify-sku@1.8.54) (2022-04-29)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.53](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.52...@contentful/shopify-sku@1.8.53) (2022-04-27)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.52](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.51...@contentful/shopify-sku@1.8.52) (2022-04-27)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.51](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.50...@contentful/shopify-sku@1.8.51) (2022-04-27)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.50](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.49...@contentful/shopify-sku@1.8.50) (2022-04-25)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.49](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.48...@contentful/shopify-sku@1.8.49) (2022-04-25)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.48](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.47...@contentful/shopify-sku@1.8.48) (2022-04-22)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.47](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.46...@contentful/shopify-sku@1.8.47) (2022-04-19)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.46](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.45...@contentful/shopify-sku@1.8.46) (2022-04-19)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.45](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.44...@contentful/shopify-sku@1.8.45) (2022-04-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.44](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.43...@contentful/shopify-sku@1.8.44) (2022-04-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.43](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.42...@contentful/shopify-sku@1.8.43) (2022-04-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.42](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.41...@contentful/shopify-sku@1.8.42) (2022-04-11)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.41](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.40...@contentful/shopify-sku@1.8.41) (2022-04-11)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.40](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.39...@contentful/shopify-sku@1.8.40) (2022-04-08)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.39](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.38...@contentful/shopify-sku@1.8.39) (2022-04-05)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.38](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.37...@contentful/shopify-sku@1.8.38) (2022-04-05)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.37](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.36...@contentful/shopify-sku@1.8.37) (2022-03-28)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.36](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.35...@contentful/shopify-sku@1.8.36) (2022-03-25)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.35](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.34...@contentful/shopify-sku@1.8.35) (2022-03-25)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.34](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.33...@contentful/shopify-sku@1.8.34) (2022-03-24)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.33](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.32...@contentful/shopify-sku@1.8.33) (2022-03-24)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.32](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.31...@contentful/shopify-sku@1.8.32) (2022-03-22)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.31](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.30...@contentful/shopify-sku@1.8.31) (2022-03-21)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.30](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.29...@contentful/shopify-sku@1.8.30) (2022-03-21)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.29](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.28...@contentful/shopify-sku@1.8.29) (2022-03-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.28](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.27...@contentful/shopify-sku@1.8.28) (2022-03-11)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.27](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.26...@contentful/shopify-sku@1.8.27) (2022-03-03)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.26](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.25...@contentful/shopify-sku@1.8.26) (2022-03-02)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.25](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.24...@contentful/shopify-sku@1.8.25) (2022-02-28)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.24](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.23...@contentful/shopify-sku@1.8.24) (2022-02-24)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.23](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.22...@contentful/shopify-sku@1.8.23) (2022-02-24)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.22](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.21...@contentful/shopify-sku@1.8.22) (2022-02-24)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.21](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.20...@contentful/shopify-sku@1.8.21) (2022-02-22)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.20](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.19...@contentful/shopify-sku@1.8.20) (2022-02-21)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.19](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.18...@contentful/shopify-sku@1.8.19) (2022-02-17)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.18](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.17...@contentful/shopify-sku@1.8.18) (2022-02-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.17](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.16...@contentful/shopify-sku@1.8.17) (2022-02-15)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.16](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.15...@contentful/shopify-sku@1.8.16) (2022-02-08)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.15](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.14...@contentful/shopify-sku@1.8.15) (2022-02-08)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.14](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.13...@contentful/shopify-sku@1.8.14) (2022-02-07)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.13](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.12...@contentful/shopify-sku@1.8.13) (2022-02-07)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.12](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.11...@contentful/shopify-sku@1.8.12) (2022-02-04)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.11](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.10...@contentful/shopify-sku@1.8.11) (2022-02-02)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.10](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.9...@contentful/shopify-sku@1.8.10) (2022-01-28)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.9](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.8...@contentful/shopify-sku@1.8.9) (2022-01-26)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.8](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.7...@contentful/shopify-sku@1.8.8) (2022-01-22)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.7](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.6...@contentful/shopify-sku@1.8.7) (2022-01-21)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.6](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.5...@contentful/shopify-sku@1.8.6) (2022-01-21)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.5](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.4...@contentful/shopify-sku@1.8.5) (2022-01-19)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.4](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.3...@contentful/shopify-sku@1.8.4) (2022-01-18)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.3](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.2...@contentful/shopify-sku@1.8.3) (2022-01-18)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.2](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.1...@contentful/shopify-sku@1.8.2) (2022-01-17)

**Note:** Version bump only for package @contentful/shopify-sku





## [1.8.1](https://github.com/contentful/apps/compare/@contentful/shopify-sku@1.8.0...@contentful/shopify-sku@1.8.1) (2022-01-16)

**Note:** Version bump only for package @contentful/shopify-sku





# 1.8.0 (2022-01-14)


### Bug Fixes

* [] Fix Shopify not displaying missing SKUs for collections/products ([#506](https://github.com/contentful/apps/issues/506)) ([3a3b736](https://github.com/contentful/apps/commit/3a3b73635c783673619c47bdbea15c643c9c0679))
* move react to peer dependency & unpin dependencies ([#475](https://github.com/contentful/apps/issues/475)) ([981e177](https://github.com/contentful/apps/commit/981e177092fafdcce211822277d3ee0dad7ae689))
* pin version for ecommerce base app ([#193](https://github.com/contentful/apps/issues/193)) ([0984a04](https://github.com/contentful/apps/commit/0984a044244df77d90190a8f110af7825a676628))
* remove unused dependencies ([#523](https://github.com/contentful/apps/issues/523)) ([a1af1dd](https://github.com/contentful/apps/commit/a1af1dd07726c1119e0c16fcbdfb3bea4f88dae2))
* **Shopify:** 'load more' button was wrongly displayed in some edge cases ([#218](https://github.com/contentful/apps/issues/218)) ([7675f84](https://github.com/contentful/apps/commit/7675f8426eaa4a979cc622d873d502ee33b9b92e))
* stop simultaneous recursive chains ([#225](https://github.com/contentful/apps/issues/225)) ([0433a5d](https://github.com/contentful/apps/commit/0433a5d587479d311395d16ef8f20c7dc3bfbc4d))
* use latest version of shopify-buy ([#213](https://github.com/contentful/apps/issues/213)) ([ba84070](https://github.com/contentful/apps/commit/ba84070c5352720b457731ebc9891f7472a3cbeb))


### Features

* [] Extend Shopify app support to products and collections ([#340](https://github.com/contentful/apps/issues/340)) ([6bf4080](https://github.com/contentful/apps/commit/6bf40807cd6ecd7810f62420de2da9a8b444bd5c))
* [EXT-2533] use new version of ecommerce base app ([#239](https://github.com/contentful/apps/issues/239)) ([b4f398f](https://github.com/contentful/apps/commit/b4f398f7fe4fb2952e8505a7657b876861fe3a24))
* [EXT-2717] deploy shopify with app hosting ([#367](https://github.com/contentful/apps/issues/367)) ([0a38ecb](https://github.com/contentful/apps/commit/0a38ecb85a59c5be46f8f1be06681f6c2e1acbcf))
* [EXT-2722] use contentful hosting for image focal point app ([#238](https://github.com/contentful/apps/issues/238)) ([11b57ae](https://github.com/contentful/apps/commit/11b57ae3e4fb5dd376544d89056430b71883517c))
* [EXT-2785] show variant SKU in shopify SKU picker ([#277](https://github.com/contentful/apps/issues/277)) ([c72fff3](https://github.com/contentful/apps/commit/c72fff3372d745cdb9b333415067e57aba419b74))
* [EXT-3415] move all package names to [@contentful](https://github.com/contentful) ([#665](https://github.com/contentful/apps/issues/665)) ([9bd7534](https://github.com/contentful/apps/commit/9bd75340860e59f25b4eed900a832a482508f603))
* add option to change search debounce time ([#220](https://github.com/contentful/apps/issues/220)) ([0493357](https://github.com/contentful/apps/commit/0493357b7e8d28a5ad0ee7b0668f82f4febe7732))
* use cca in shopify app ([#267](https://github.com/contentful/apps/issues/267)) ([217ec31](https://github.com/contentful/apps/commit/217ec31928e684c13f49fc57237327d0b8d2c725))


### Reverts

* Revert "feat: [EXT-2533] use new version of ecommerce base app (#239)" (#251) ([dae2ae6](https://github.com/contentful/apps/commit/dae2ae66181543a93981b1b97cc9dfc71e5abf16)), closes [#239](https://github.com/contentful/apps/issues/239) [#251](https://github.com/contentful/apps/issues/251)



## 1.0.1 (2021-01-11)



# 1.0.0 (2021-01-08)





## [1.7.87](https://github.com/contentful/apps/compare/shopify-sku@1.7.86...shopify-sku@1.7.87) (2022-01-10)

**Note:** Version bump only for package shopify-sku





## [1.7.86](https://github.com/contentful/apps/compare/shopify-sku@1.7.85...shopify-sku@1.7.86) (2022-01-06)

**Note:** Version bump only for package shopify-sku





## [1.7.85](https://github.com/contentful/apps/compare/shopify-sku@1.7.84...shopify-sku@1.7.85) (2022-01-05)

**Note:** Version bump only for package shopify-sku





## [1.7.84](https://github.com/contentful/apps/compare/shopify-sku@1.7.83...shopify-sku@1.7.84) (2022-01-05)

**Note:** Version bump only for package shopify-sku





## [1.7.83](https://github.com/contentful/apps/compare/shopify-sku@1.7.82...shopify-sku@1.7.83) (2022-01-04)

**Note:** Version bump only for package shopify-sku





## [1.7.82](https://github.com/contentful/apps/compare/shopify-sku@1.7.81...shopify-sku@1.7.82) (2022-01-03)

**Note:** Version bump only for package shopify-sku





## [1.7.81](https://github.com/contentful/apps/compare/shopify-sku@1.7.80...shopify-sku@1.7.81) (2021-12-31)

**Note:** Version bump only for package shopify-sku





## [1.7.80](https://github.com/contentful/apps/compare/shopify-sku@1.7.79...shopify-sku@1.7.80) (2021-12-27)

**Note:** Version bump only for package shopify-sku





## [1.7.79](https://github.com/contentful/apps/compare/shopify-sku@1.7.78...shopify-sku@1.7.79) (2021-12-24)

**Note:** Version bump only for package shopify-sku





## [1.7.78](https://github.com/contentful/apps/compare/shopify-sku@1.7.77...shopify-sku@1.7.78) (2021-12-24)

**Note:** Version bump only for package shopify-sku





## [1.7.77](https://github.com/contentful/apps/compare/shopify-sku@1.7.76...shopify-sku@1.7.77) (2021-12-21)

**Note:** Version bump only for package shopify-sku





## [1.7.76](https://github.com/contentful/apps/compare/shopify-sku@1.7.75...shopify-sku@1.7.76) (2021-12-20)

**Note:** Version bump only for package shopify-sku





## [1.7.75](https://github.com/contentful/apps/compare/shopify-sku@1.7.74...shopify-sku@1.7.75) (2021-12-17)

**Note:** Version bump only for package shopify-sku





## [1.7.74](https://github.com/contentful/apps/compare/shopify-sku@1.7.73...shopify-sku@1.7.74) (2021-12-16)

**Note:** Version bump only for package shopify-sku





## [1.7.73](https://github.com/contentful/apps/compare/shopify-sku@1.7.72...shopify-sku@1.7.73) (2021-12-15)

**Note:** Version bump only for package shopify-sku





## [1.7.72](https://github.com/contentful/apps/compare/shopify-sku@1.7.71...shopify-sku@1.7.72) (2021-12-14)

**Note:** Version bump only for package shopify-sku





## [1.7.71](https://github.com/contentful/apps/compare/shopify-sku@1.7.70...shopify-sku@1.7.71) (2021-12-13)

**Note:** Version bump only for package shopify-sku





## [1.7.70](https://github.com/contentful/apps/compare/shopify-sku@1.7.69...shopify-sku@1.7.70) (2021-12-10)

**Note:** Version bump only for package shopify-sku





## [1.7.69](https://github.com/contentful/apps/compare/shopify-sku@1.7.68...shopify-sku@1.7.69) (2021-12-09)

**Note:** Version bump only for package shopify-sku





## [1.7.68](https://github.com/contentful/apps/compare/shopify-sku@1.7.67...shopify-sku@1.7.68) (2021-12-08)

**Note:** Version bump only for package shopify-sku





## [1.7.67](https://github.com/contentful/apps/compare/shopify-sku@1.7.66...shopify-sku@1.7.67) (2021-12-06)

**Note:** Version bump only for package shopify-sku





## [1.7.66](https://github.com/contentful/apps/compare/shopify-sku@1.7.65...shopify-sku@1.7.66) (2021-12-02)

**Note:** Version bump only for package shopify-sku





## [1.7.65](https://github.com/contentful/apps/compare/shopify-sku@1.7.64...shopify-sku@1.7.65) (2021-12-01)

**Note:** Version bump only for package shopify-sku





## [1.7.64](https://github.com/contentful/apps/compare/shopify-sku@1.7.63...shopify-sku@1.7.64) (2021-12-01)

**Note:** Version bump only for package shopify-sku





## [1.7.63](https://github.com/contentful/apps/compare/shopify-sku@1.7.62...shopify-sku@1.7.63) (2021-11-30)

**Note:** Version bump only for package shopify-sku





## [1.7.62](https://github.com/contentful/apps/compare/shopify-sku@1.7.61...shopify-sku@1.7.62) (2021-11-26)

**Note:** Version bump only for package shopify-sku





## [1.7.61](https://github.com/contentful/apps/compare/shopify-sku@1.7.60...shopify-sku@1.7.61) (2021-11-25)

**Note:** Version bump only for package shopify-sku





## [1.7.60](https://github.com/contentful/apps/compare/shopify-sku@1.7.59...shopify-sku@1.7.60) (2021-11-24)

**Note:** Version bump only for package shopify-sku





## [1.7.59](https://github.com/contentful/apps/compare/shopify-sku@1.7.58...shopify-sku@1.7.59) (2021-11-22)

**Note:** Version bump only for package shopify-sku





## [1.7.58](https://github.com/contentful/apps/compare/shopify-sku@1.7.57...shopify-sku@1.7.58) (2021-11-22)

**Note:** Version bump only for package shopify-sku





## [1.7.57](https://github.com/contentful/apps/compare/shopify-sku@1.7.56...shopify-sku@1.7.57) (2021-11-19)

**Note:** Version bump only for package shopify-sku





## [1.7.56](https://github.com/contentful/apps/compare/shopify-sku@1.7.55...shopify-sku@1.7.56) (2021-11-19)

**Note:** Version bump only for package shopify-sku





## [1.7.55](https://github.com/contentful/apps/compare/shopify-sku@1.7.54...shopify-sku@1.7.55) (2021-11-16)

**Note:** Version bump only for package shopify-sku





## [1.7.54](https://github.com/contentful/apps/compare/shopify-sku@1.7.53...shopify-sku@1.7.54) (2021-11-15)

**Note:** Version bump only for package shopify-sku





## [1.7.53](https://github.com/contentful/apps/compare/shopify-sku@1.7.52...shopify-sku@1.7.53) (2021-11-15)

**Note:** Version bump only for package shopify-sku





## [1.7.52](https://github.com/contentful/apps/compare/shopify-sku@1.7.51...shopify-sku@1.7.52) (2021-11-09)

**Note:** Version bump only for package shopify-sku





## [1.7.51](https://github.com/contentful/apps/compare/shopify-sku@1.7.50...shopify-sku@1.7.51) (2021-11-08)

**Note:** Version bump only for package shopify-sku





## [1.7.50](https://github.com/contentful/apps/compare/shopify-sku@1.7.49...shopify-sku@1.7.50) (2021-11-04)

**Note:** Version bump only for package shopify-sku





## [1.7.49](https://github.com/contentful/apps/compare/shopify-sku@1.7.48...shopify-sku@1.7.49) (2021-11-04)

**Note:** Version bump only for package shopify-sku





## [1.7.48](https://github.com/contentful/apps/compare/shopify-sku@1.7.47...shopify-sku@1.7.48) (2021-10-28)

**Note:** Version bump only for package shopify-sku





## [1.7.47](https://github.com/contentful/apps/compare/shopify-sku@1.7.46...shopify-sku@1.7.47) (2021-10-26)

**Note:** Version bump only for package shopify-sku





## [1.7.46](https://github.com/contentful/apps/compare/shopify-sku@1.7.45...shopify-sku@1.7.46) (2021-10-26)

**Note:** Version bump only for package shopify-sku





## [1.7.45](https://github.com/contentful/apps/compare/shopify-sku@1.7.44...shopify-sku@1.7.45) (2021-10-25)

**Note:** Version bump only for package shopify-sku





## [1.7.44](https://github.com/contentful/apps/compare/shopify-sku@1.7.43...shopify-sku@1.7.44) (2021-10-25)

**Note:** Version bump only for package shopify-sku





## [1.7.43](https://github.com/contentful/apps/compare/shopify-sku@1.7.42...shopify-sku@1.7.43) (2021-10-22)

**Note:** Version bump only for package shopify-sku





## [1.7.42](https://github.com/contentful/apps/compare/shopify-sku@1.7.41...shopify-sku@1.7.42) (2021-10-22)

**Note:** Version bump only for package shopify-sku





## [1.7.41](https://github.com/contentful/apps/compare/shopify-sku@1.7.40...shopify-sku@1.7.41) (2021-10-21)

**Note:** Version bump only for package shopify-sku





## [1.7.40](https://github.com/contentful/apps/compare/shopify-sku@1.7.39...shopify-sku@1.7.40) (2021-10-20)

**Note:** Version bump only for package shopify-sku





## [1.7.39](https://github.com/contentful/apps/compare/shopify-sku@1.7.38...shopify-sku@1.7.39) (2021-10-18)

**Note:** Version bump only for package shopify-sku





## [1.7.38](https://github.com/contentful/apps/compare/shopify-sku@1.7.37...shopify-sku@1.7.38) (2021-10-18)

**Note:** Version bump only for package shopify-sku





## [1.7.37](https://github.com/contentful/apps/compare/shopify-sku@1.7.36...shopify-sku@1.7.37) (2021-10-15)

**Note:** Version bump only for package shopify-sku





## [1.7.36](https://github.com/contentful/apps/compare/shopify-sku@1.7.35...shopify-sku@1.7.36) (2021-10-15)

**Note:** Version bump only for package shopify-sku





## [1.7.35](https://github.com/contentful/apps/compare/shopify-sku@1.7.34...shopify-sku@1.7.35) (2021-10-14)

**Note:** Version bump only for package shopify-sku





## [1.7.34](https://github.com/contentful/apps/compare/shopify-sku@1.7.33...shopify-sku@1.7.34) (2021-10-14)

**Note:** Version bump only for package shopify-sku





## [1.7.33](https://github.com/contentful/apps/compare/shopify-sku@1.7.32...shopify-sku@1.7.33) (2021-10-13)

**Note:** Version bump only for package shopify-sku





## [1.7.32](https://github.com/contentful/apps/compare/shopify-sku@1.7.31...shopify-sku@1.7.32) (2021-10-13)

**Note:** Version bump only for package shopify-sku





## [1.7.31](https://github.com/contentful/apps/compare/shopify-sku@1.7.30...shopify-sku@1.7.31) (2021-10-13)

**Note:** Version bump only for package shopify-sku





## [1.7.30](https://github.com/contentful/apps/compare/shopify-sku@1.7.29...shopify-sku@1.7.30) (2021-10-11)

**Note:** Version bump only for package shopify-sku





## [1.7.29](https://github.com/contentful/apps/compare/shopify-sku@1.7.28...shopify-sku@1.7.29) (2021-10-07)


### Bug Fixes

* remove unused dependencies ([#523](https://github.com/contentful/apps/issues/523)) ([a1af1dd](https://github.com/contentful/apps/commit/a1af1dd07726c1119e0c16fcbdfb3bea4f88dae2))





## [1.7.28](https://github.com/contentful/apps/compare/shopify-sku@1.7.27...shopify-sku@1.7.28) (2021-10-07)

**Note:** Version bump only for package shopify-sku





## [1.7.27](https://github.com/contentful/apps/compare/shopify-sku@1.7.26...shopify-sku@1.7.27) (2021-10-06)

**Note:** Version bump only for package shopify-sku





## [1.7.26](https://github.com/contentful/apps/compare/shopify-sku@1.7.25...shopify-sku@1.7.26) (2021-10-04)

**Note:** Version bump only for package shopify-sku





## [1.7.25](https://github.com/contentful/apps/compare/shopify-sku@1.7.24...shopify-sku@1.7.25) (2021-09-30)


### Bug Fixes

* [] Fix Shopify not displaying missing SKUs for collections/products ([#506](https://github.com/contentful/apps/issues/506)) ([3a3b736](https://github.com/contentful/apps/commit/3a3b73635c783673619c47bdbea15c643c9c0679))





## [1.7.24](https://github.com/contentful/apps/compare/shopify-sku@1.7.23...shopify-sku@1.7.24) (2021-09-30)

**Note:** Version bump only for package shopify-sku





## [1.7.23](https://github.com/contentful/apps/compare/shopify-sku@1.7.22...shopify-sku@1.7.23) (2021-09-29)

**Note:** Version bump only for package shopify-sku





## [1.7.22](https://github.com/contentful/apps/compare/shopify-sku@1.7.21...shopify-sku@1.7.22) (2021-09-27)

**Note:** Version bump only for package shopify-sku





## [1.7.21](https://github.com/contentful/apps/compare/shopify-sku@1.7.20...shopify-sku@1.7.21) (2021-09-24)

**Note:** Version bump only for package shopify-sku





## [1.7.20](https://github.com/contentful/apps/compare/shopify-sku@1.7.19...shopify-sku@1.7.20) (2021-09-22)

**Note:** Version bump only for package shopify-sku





## [1.7.19](https://github.com/contentful/apps/compare/shopify-sku@1.7.18...shopify-sku@1.7.19) (2021-09-22)

**Note:** Version bump only for package shopify-sku





## [1.7.18](https://github.com/contentful/apps/compare/shopify-sku@1.7.17...shopify-sku@1.7.18) (2021-09-22)

**Note:** Version bump only for package shopify-sku





## [1.7.17](https://github.com/contentful/apps/compare/shopify-sku@1.7.16...shopify-sku@1.7.17) (2021-09-21)

**Note:** Version bump only for package shopify-sku





## [1.7.16](https://github.com/contentful/apps/compare/shopify-sku@1.7.15...shopify-sku@1.7.16) (2021-09-21)

**Note:** Version bump only for package shopify-sku





## [1.7.15](https://github.com/contentful/apps/compare/shopify-sku@1.7.14...shopify-sku@1.7.15) (2021-09-20)

**Note:** Version bump only for package shopify-sku





## [1.7.14](https://github.com/contentful/apps/compare/shopify-sku@1.7.13...shopify-sku@1.7.14) (2021-09-20)

**Note:** Version bump only for package shopify-sku





## [1.7.13](https://github.com/contentful/apps/compare/shopify-sku@1.7.12...shopify-sku@1.7.13) (2021-09-17)

**Note:** Version bump only for package shopify-sku





## [1.7.12](https://github.com/contentful/apps/compare/shopify-sku@1.7.11...shopify-sku@1.7.12) (2021-09-17)

**Note:** Version bump only for package shopify-sku





## [1.7.11](https://github.com/contentful/apps/compare/shopify-sku@1.7.10...shopify-sku@1.7.11) (2021-09-17)

**Note:** Version bump only for package shopify-sku





## [1.7.10](https://github.com/contentful/apps/compare/shopify-sku@1.7.9...shopify-sku@1.7.10) (2021-09-17)

**Note:** Version bump only for package shopify-sku





## [1.7.9](https://github.com/contentful/apps/compare/shopify-sku@1.7.8...shopify-sku@1.7.9) (2021-09-16)

**Note:** Version bump only for package shopify-sku





## [1.7.8](https://github.com/contentful/apps/compare/shopify-sku@1.7.7...shopify-sku@1.7.8) (2021-09-16)


### Bug Fixes

* move react to peer dependency & unpin dependencies ([#475](https://github.com/contentful/apps/issues/475)) ([981e177](https://github.com/contentful/apps/commit/981e177092fafdcce211822277d3ee0dad7ae689))





## [1.7.7](https://github.com/contentful/apps/compare/shopify-sku@1.7.6...shopify-sku@1.7.7) (2021-09-13)

**Note:** Version bump only for package shopify-sku





## [1.7.6](https://github.com/contentful/apps/compare/shopify-sku@1.7.5...shopify-sku@1.7.6) (2021-09-10)

**Note:** Version bump only for package shopify-sku





## [1.7.5](https://github.com/contentful/apps/compare/shopify-sku@1.7.4...shopify-sku@1.7.5) (2021-09-10)

**Note:** Version bump only for package shopify-sku





## [1.7.4](https://github.com/contentful/apps/compare/shopify-sku@1.7.3...shopify-sku@1.7.4) (2021-09-06)

**Note:** Version bump only for package shopify-sku





## [1.7.3](https://github.com/contentful/apps/compare/shopify-sku@1.7.2...shopify-sku@1.7.3) (2021-09-03)

**Note:** Version bump only for package shopify-sku





## [1.7.2](https://github.com/contentful/apps/compare/shopify-sku@1.7.1...shopify-sku@1.7.2) (2021-09-03)

**Note:** Version bump only for package shopify-sku





## [1.7.1](https://github.com/contentful/apps/compare/shopify-sku@1.7.0...shopify-sku@1.7.1) (2021-09-03)

**Note:** Version bump only for package shopify-sku





# [1.7.0](https://github.com/contentful/apps/compare/shopify-sku@1.6.15...shopify-sku@1.7.0) (2021-09-02)


### Features

* [] Extend Shopify app support to products and collections ([#340](https://github.com/contentful/apps/issues/340)) ([6bf4080](https://github.com/contentful/apps/commit/6bf40807cd6ecd7810f62420de2da9a8b444bd5c))





## [1.6.15](https://github.com/contentful/apps/compare/shopify-sku@1.6.14...shopify-sku@1.6.15) (2021-09-02)

**Note:** Version bump only for package shopify-sku





## [1.6.14](https://github.com/contentful/apps/compare/shopify-sku@1.6.13...shopify-sku@1.6.14) (2021-08-30)

**Note:** Version bump only for package shopify-sku





## [1.6.13](https://github.com/contentful/apps/compare/shopify-sku@1.6.12...shopify-sku@1.6.13) (2021-08-25)

**Note:** Version bump only for package shopify-sku





## [1.6.12](https://github.com/contentful/apps/compare/shopify-sku@1.6.11...shopify-sku@1.6.12) (2021-08-20)

**Note:** Version bump only for package shopify-sku





## [1.6.11](https://github.com/contentful/apps/compare/shopify-sku@1.6.10...shopify-sku@1.6.11) (2021-08-18)

**Note:** Version bump only for package shopify-sku





## [1.6.10](https://github.com/contentful/apps/compare/shopify-sku@1.6.9...shopify-sku@1.6.10) (2021-08-16)

**Note:** Version bump only for package shopify-sku





## [1.6.9](https://github.com/contentful/apps/compare/shopify-sku@1.6.8...shopify-sku@1.6.9) (2021-08-13)

**Note:** Version bump only for package shopify-sku





## [1.6.8](https://github.com/contentful/apps/compare/shopify-sku@1.6.7...shopify-sku@1.6.8) (2021-08-11)

**Note:** Version bump only for package shopify-sku





## [1.6.7](https://github.com/contentful/apps/compare/shopify-sku@1.6.6...shopify-sku@1.6.7) (2021-08-10)

**Note:** Version bump only for package shopify-sku





## [1.6.6](https://github.com/contentful/apps/compare/shopify-sku@1.6.5...shopify-sku@1.6.6) (2021-08-09)

**Note:** Version bump only for package shopify-sku





## [1.6.5](https://github.com/contentful/apps/compare/shopify-sku@1.6.4...shopify-sku@1.6.5) (2021-08-06)

**Note:** Version bump only for package shopify-sku





## [1.6.4](https://github.com/contentful/apps/compare/shopify-sku@1.6.3...shopify-sku@1.6.4) (2021-08-05)

**Note:** Version bump only for package shopify-sku





## [1.6.3](https://github.com/contentful/apps/compare/shopify-sku@1.6.2...shopify-sku@1.6.3) (2021-08-05)

**Note:** Version bump only for package shopify-sku





## [1.6.2](https://github.com/contentful/apps/compare/shopify-sku@1.6.1...shopify-sku@1.6.2) (2021-08-02)

**Note:** Version bump only for package shopify-sku





## [1.6.1](https://github.com/contentful/apps/compare/shopify-sku@1.6.0...shopify-sku@1.6.1) (2021-08-02)

**Note:** Version bump only for package shopify-sku





# [1.6.0](https://github.com/contentful/apps/compare/shopify-sku@1.5.9...shopify-sku@1.6.0) (2021-07-30)


### Features

* [EXT-2717] deploy shopify with app hosting ([#367](https://github.com/contentful/apps/issues/367)) ([0a38ecb](https://github.com/contentful/apps/commit/0a38ecb85a59c5be46f8f1be06681f6c2e1acbcf))





## [1.5.9](https://github.com/contentful/apps/compare/shopify-sku@1.5.8...shopify-sku@1.5.9) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.8](https://github.com/contentful/apps/compare/shopify-sku@1.5.7...shopify-sku@1.5.8) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.7](https://github.com/contentful/apps/compare/shopify-sku@1.5.6...shopify-sku@1.5.7) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.6](https://github.com/contentful/apps/compare/shopify-sku@1.5.5...shopify-sku@1.5.6) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.5](https://github.com/contentful/apps/compare/shopify-sku@1.5.4...shopify-sku@1.5.5) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.4](https://github.com/contentful/apps/compare/shopify-sku@1.5.3...shopify-sku@1.5.4) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.3](https://github.com/contentful/apps/compare/shopify-sku@1.5.2...shopify-sku@1.5.3) (2021-07-28)

**Note:** Version bump only for package shopify-sku





## [1.5.2](https://github.com/contentful/apps/compare/shopify-sku@1.5.1...shopify-sku@1.5.2) (2021-07-26)

**Note:** Version bump only for package shopify-sku





## [1.5.1](https://github.com/contentful/apps/compare/shopify-sku@1.5.0...shopify-sku@1.5.1) (2021-06-22)

**Note:** Version bump only for package shopify-sku





# [1.5.0](https://github.com/contentful/apps/compare/shopify-sku@1.4.0...shopify-sku@1.5.0) (2021-06-15)


### Features

* [EXT-2785] show variant SKU in shopify SKU picker ([#277](https://github.com/contentful/apps/issues/277)) ([c72fff3](https://github.com/contentful/apps/commit/c72fff3372d745cdb9b333415067e57aba419b74))





# [1.4.0](https://github.com/contentful/apps/compare/shopify-sku@1.3.1...shopify-sku@1.4.0) (2021-05-26)


### Features

* use cca in shopify app ([#267](https://github.com/contentful/apps/issues/267)) ([217ec31](https://github.com/contentful/apps/commit/217ec31928e684c13f49fc57237327d0b8d2c725))





## [1.3.1](https://github.com/contentful/apps/compare/shopify-sku@1.3.0...shopify-sku@1.3.1) (2021-05-10)


### Reverts

* Revert "feat: [EXT-2533] use new version of ecommerce base app (#239)" (#251) ([dae2ae6](https://github.com/contentful/apps/commit/dae2ae66181543a93981b1b97cc9dfc71e5abf16)), closes [#239](https://github.com/contentful/apps/issues/239) [#251](https://github.com/contentful/apps/issues/251)





# [1.3.0](https://github.com/contentful/apps/compare/shopify-sku@1.2.0...shopify-sku@1.3.0) (2021-05-10)


### Features

* [EXT-2533] use new version of ecommerce base app ([#239](https://github.com/contentful/apps/issues/239)) ([b4f398f](https://github.com/contentful/apps/commit/b4f398f7fe4fb2952e8505a7657b876861fe3a24))





# [1.2.0](https://github.com/contentful/apps/compare/shopify-sku@1.1.1...shopify-sku@1.2.0) (2021-05-05)


### Features

* [EXT-2722] use contentful hosting for image focal point app ([#238](https://github.com/contentful/apps/issues/238)) ([11b57ae](https://github.com/contentful/apps/commit/11b57ae3e4fb5dd376544d89056430b71883517c))





## [1.1.1](https://github.com/contentful/apps/compare/shopify-sku@1.1.0...shopify-sku@1.1.1) (2021-04-21)


### Bug Fixes

* stop simultaneous recursive chains ([#225](https://github.com/contentful/apps/issues/225)) ([0433a5d](https://github.com/contentful/apps/commit/0433a5d587479d311395d16ef8f20c7dc3bfbc4d))





# [1.1.0](https://github.com/contentful/apps/compare/shopify-sku@1.0.9...shopify-sku@1.1.0) (2021-04-13)


### Features

* add option to change search debounce time ([#220](https://github.com/contentful/apps/issues/220)) ([0493357](https://github.com/contentful/apps/commit/0493357b7e8d28a5ad0ee7b0668f82f4febe7732))





## [1.0.9](https://github.com/contentful/apps/compare/shopify-sku@1.0.8...shopify-sku@1.0.9) (2021-04-07)


### Bug Fixes

* **Shopify:** 'load more' button was wrongly displayed in some edge cases ([#218](https://github.com/contentful/apps/issues/218)) ([7675f84](https://github.com/contentful/apps/commit/7675f8426eaa4a979cc622d873d502ee33b9b92e))





## [1.0.8](https://github.com/contentful/apps/compare/shopify-sku@1.0.7...shopify-sku@1.0.8) (2021-04-06)


### Bug Fixes

* use latest version of shopify-buy ([#213](https://github.com/contentful/apps/issues/213)) ([ba84070](https://github.com/contentful/apps/commit/ba84070c5352720b457731ebc9891f7472a3cbeb))





## [1.0.7](https://github.com/contentful/apps/compare/shopify-sku@1.0.6...shopify-sku@1.0.7) (2021-02-16)


### Bug Fixes

* pin version for ecommerce base app ([#193](https://github.com/contentful/apps/issues/193)) ([0984a04](https://github.com/contentful/apps/commit/0984a044244df77d90190a8f110af7825a676628))





## [1.0.6](https://github.com/contentful/apps/compare/shopify-sku@1.0.5...shopify-sku@1.0.6) (2021-02-16)

**Note:** Version bump only for package shopify-sku





## [1.0.5](https://github.com/contentful/apps/compare/shopify-sku@1.0.4...shopify-sku@1.0.5) (2021-02-02)

**Note:** Version bump only for package shopify-sku





## [1.0.4](https://github.com/contentful/apps/compare/shopify-sku@1.0.3...shopify-sku@1.0.4) (2021-01-14)

**Note:** Version bump only for package shopify-sku





## [1.0.3](https://github.com/contentful/apps/compare/shopify-sku@1.0.2...shopify-sku@1.0.3) (2021-01-14)

**Note:** Version bump only for package shopify-sku





## 1.0.2 (2021-01-12)



## 1.0.1 (2021-01-11)



# 1.0.0 (2021-01-08)

**Note:** Version bump only for package shopify-sku
