# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.2](https://github.com/contentful/apps/compare/@contentful/graphql-playground@0.2.1...@contentful/graphql-playground@0.2.2) (2022-04-11)

**Note:** Version bump only for package @contentful/graphql-playground





## [0.2.1](https://github.com/contentful/apps/compare/@contentful/graphql-playground@0.2.0...@contentful/graphql-playground@0.2.1) (2022-04-11)

**Note:** Version bump only for package @contentful/graphql-playground





# 0.2.0 (2022-04-11)


### Features

* Add graphql playground with git subtree ([#1061](https://github.com/contentful/apps/issues/1061)) ([4b00046](https://github.com/contentful/apps/commit/4b00046216414d5ba8c9737292725160be046007))
