# Contentful DAM Demo App

Learn more about how to use [`@contentful/dam-app-base`](https://www.npmjs.com/package/@contentful/dam-app-base) in our [documentation](https://www.contentful.com/developers/docs/extensibility/app-framework/libraries/).
