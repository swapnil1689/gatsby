# Contentful E-Commerce Demo App

Learn more about how to use [`@contentful/ecommerce-app-base`](https://www.npmjs.com/package/@contentful/ecommerce-app-base) in our [documentation](https://www.contentful.com/developers/docs/extensibility/app-framework/libraries/).
